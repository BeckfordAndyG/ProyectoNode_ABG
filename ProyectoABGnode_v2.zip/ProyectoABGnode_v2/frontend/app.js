const API = '/api';
let TOKEN = localStorage.getItem('TOKEN') || null;

const authHeaders = () => TOKEN ? { 'Authorization': 'Bearer ' + TOKEN } : {};

async function registro(e){
  e.preventDefault();
  const fd = new FormData(e.target);
  const body = Object.fromEntries(fd.entries());
  const res = await fetch(API + '/usuarios/registro', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const data = await res.json();
  alert(res.ok ? 'Registro ok' : (data.mensaje || 'Error'));
  if(res.ok) e.target.reset();
}

async function login(e){
  e.preventDefault();
  const fd = new FormData(e.target);
  const body = Object.fromEntries(fd.entries());
  const res = await fetch(API + '/usuarios/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if(res.ok){
    TOKEN = data.token; localStorage.setItem('TOKEN', TOKEN);
    document.querySelector('#perfilBox').innerHTML = '<small class="mono">Logueado como: '+ data.usuario.nombre +' ('+ data.usuario.email + ')</small>';
    alert('Login ok');
    cargar();
  } else alert(data.mensaje || 'Error');
}

async function crearCamiseta(e){
  e.preventDefault();
  if(!TOKEN) return alert('Necesitas iniciar sesión');
  const fd = new FormData(e.target);
  const res = await fetch(API + '/camisetas', { method: 'POST', headers: authHeaders(), body: fd });
  const data = await res.json();
  if(res.ok){ e.target.reset(); cargar(); } else alert(data.mensaje || 'Error creando');
}

function renderCarrusel(items){
  const cont = document.getElementById('carrusel');
  cont.innerHTML = items.map(c => `
    <div class="card">
      <img src="${c.imagen ? '/uploads/' + c.imagen : 'https://via.placeholder.com/400x300?text=Camiseta'}" alt="camiseta">
      <div><strong>${c.color}</strong> · <span class="tag">${c.talla}</span></div>
      <div class="actions">
        <div>
          <button onclick="votar('${c._id}','positivo')">👍</button>
          <span class="badge pos">+ ${c.votos?.positivos || 0}</span>
          <button onclick="votar('${c._id}','negativo')">👎</button>
          <span class="badge neg">- ${c.votos?.negativos || 0}</span>
        </div>
        <div>
          <button onclick="eliminar('${c._id}')">🗑️</button>
        </div>
      </div>
    </div>
  `).join('');
}

function renderTabla(items){
  const tb = document.getElementById('tablaBody');
  tb.innerHTML = items.map(c => `
    <tr>
      <td>${c.imagen ? '<img src="/uploads/'+c.imagen+'" width="60"/>' : '-'}</td>
      <td>${c.color}</td>
      <td>${c.talla}</td>
      <td>+${c.votos?.positivos || 0} / -${c.votos?.negativos || 0}</td>
      <td>
        <button onclick="votar('${c._id}','positivo')">👍</button>
        <button onclick="votar('${c._id}','negativo')">👎</button>
      </td>
    </tr>
  `).join('');
}

async function cargar(){
  const res = await fetch(API + '/camisetas/con-votos');
  const data = await res.json();
  renderCarrusel(data);
  renderTabla(data);
}

async function votar(id, voto){
  if(!TOKEN) return alert('Necesitas iniciar sesión');
  const res = await fetch(API + '/votaciones', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ camisetaId: id, voto })
  });
  if(res.ok) cargar();
  else {
    const data = await res.json();
    alert(data.mensaje || 'Error al votar');
  }
}

async function eliminar(id){
  if(!TOKEN) return alert('Necesitas iniciar sesión');
  if(!confirm('¿Eliminar camiseta?')) return;
  const res = await fetch(API + '/camisetas/' + id, { method: 'DELETE', headers: authHeaders() });
  if(res.ok) cargar(); else alert('No se pudo eliminar');
}

// Eventos
document.getElementById('formRegistro').addEventListener('submit', registro);
document.getElementById('formLogin').addEventListener('submit', login);
document.getElementById('formCamiseta').addEventListener('submit', crearCamiseta);

cargar();


const tabla = document.querySelector("table");
if (tabla) tabla.classList.remove("hidden");
