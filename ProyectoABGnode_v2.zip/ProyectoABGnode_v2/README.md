# ProyectoABGnode — Sistema de Gestión de Camisetas Deportivas

Autor: **Andy Beckford**

## 📦 Estructura
```
ProyectoABGnode/
├─ backend/
│  ├─ controllers/
│  ├─ middleware/
│  ├─ models/
│  ├─ routes/
│  ├─ uploads/           # imágenes
│  ├─ server.js
│  ├─ config.js
│  └─ package.json
└─ frontend/
   ├─ index.html
   ├─ app.js
   └─ styles.css
```

## 🚀 Puesta en marcha
1. Tener **Node 18+** y **MongoDB** en local.
2. Instalar dependencias:
   ```bash
   cd backend
   npm install
   ```
3. Variables (opcional): crear `backend/.env`
   ```env
   PORT=3000
   MONGODB_URI=mongodb://127.0.0.1:27017/proyectoabg
   JWT_SECRET=super_secreto_de_andy_beckford
   ```
4. Ejecutar:
   ```bash
   npm run dev
   # o
   npm start
   ```
5. Abrir: `http://localhost:3000`

## 🧩 Rúbrica cubierta
- **MongoDB + Mongoose (20 pts)**: modelos `Usuario`, `Camiseta`, `Votacion` con relaciones y restricciones (única votación por usuario/camiseta).
- **API REST (25 pts)**: CRUD completo para camisetas + auth de usuarios + votaciones. Rutas:
  - `POST /api/usuarios/registro`
  - `POST /api/usuarios/login`
  - `GET /api/usuarios/perfil` (JWT)
  - `GET /api/camisetas` · `GET /api/camisetas/:id`
  - `POST /api/camisetas` (JWT + Multer)
  - `PUT /api/camisetas/:id` (JWT + Multer)
  - `DELETE /api/camisetas/:id` (JWT)
  - `POST /api/votaciones` (JWT)
  - `GET /api/votaciones/resumen/:id`
  - `GET /api/camisetas/con-votos` (agregado para el frontend)
- **Frontend (20 pts)**: `frontend/` con formulario de registro, login, subida de camiseta, **carrusel** y **tabla** consumiendo API con **fetch**.
- **Manejo de archivos (15 pts)**: subida con **Multer** a `backend/uploads` y servido estático en `/uploads`.
- **Seguridad (10 pts)**: **JWT** en rutas protegidas, **bcrypt** para contraseñas.
- **Documentación (10 pts)**: este README + comentarios en código.

## 🔐 Notas de seguridad
- Cambia `JWT_SECRET` en producción.
- Valida el tipo/tamaño de imagen en Multer si es necesario.

## 🧪 Pruebas rápidas con cURL
```bash
# Registro
curl -X POST http://localhost:3000/api/usuarios/registro -H "Content-Type: application/json" -d '{"nombre":"Andy Beckford","email":"andy@example.com","password":"secret123"}'

# Login
curl -X POST http://localhost:3000/api/usuarios/login -H "Content-Type: application/json" -d '{"email":"andy@example.com","password":"secret123"}'

# Listado camisetas
curl http://localhost:3000/api/camisetas
```

¡Listo para correr y evaluar! ✅