const mongoose = require('mongoose');

const camisetaSchema = new mongoose.Schema({
  color: { type: String, required: true, trim: true },
  talla: { type: String, enum: ['S', 'M', 'L', 'XL'], required: true },
  imagen: { type: String }, // filename stored in /uploads
  descripcion: { type: String, default: '' },
  fechaRegistro: { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model('Camiseta', camisetaSchema);