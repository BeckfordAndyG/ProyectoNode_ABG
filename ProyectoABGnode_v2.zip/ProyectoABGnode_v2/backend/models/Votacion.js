const mongoose = require('mongoose');

const votacionSchema = new mongoose.Schema({
  usuario: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario', required: true },
  camiseta: { type: mongoose.Schema.Types.ObjectId, ref: 'Camiseta', required: true },
  voto: { type: String, enum: ['positivo', 'negativo'], required: true }
}, { timestamps: true });

votacionSchema.index({ usuario: 1, camiseta: 1 }, { unique: true });

module.exports = mongoose.model('Votacion', votacionSchema);