const router = require('express').Router();
const ctrl = require('../controllers/usuarioController');
const auth = require('../middleware/authMiddleware');

router.post('/registro', ctrl.registro);
router.post('/login', ctrl.login);
router.get('/perfil', auth, ctrl.perfil);

module.exports = router;