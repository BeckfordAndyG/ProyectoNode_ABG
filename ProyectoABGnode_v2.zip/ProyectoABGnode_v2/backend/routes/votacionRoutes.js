const router = require('express').Router();
const ctrl = require('../controllers/votacionController');
const auth = require('../middleware/authMiddleware');

router.post('/', auth, ctrl.votar);
router.get('/resumen/:id', ctrl.resumenPorCamiseta);

module.exports = router;