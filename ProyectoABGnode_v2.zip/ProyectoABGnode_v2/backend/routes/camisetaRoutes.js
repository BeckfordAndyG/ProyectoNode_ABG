const router = require('express').Router();
const ctrl = require('../controllers/camisetaController');
const auth = require('../middleware/authMiddleware');
const multer = require('multer');
const path = require('path');
const { UPLOADS_DIR } = require('../config');

const storage = multer.diskStorage({
  destination: function(_req, _file, cb) {
    cb(null, path.join(__dirname, '..', UPLOADS_DIR));
  },
  filename: function(_req, file, cb) {
    const safe = Date.now() + '-' + file.originalname.replace(/\s+/g, '_');
    cb(null, safe);
  }
});
const upload = multer({ storage });

router.get('/', ctrl.listar);
router.get('/con-votos', require('../controllers/votacionController').listaConVotos);
router.get('/:id', ctrl.obtener);
router.post('/', auth, upload.single('imagen'), ctrl.crear);
router.put('/:id', auth, upload.single('imagen'), ctrl.actualizar);
router.delete('/:id', auth, ctrl.eliminar);

module.exports = router;