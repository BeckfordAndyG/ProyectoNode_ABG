const jwt = require('jsonwebtoken');
const Usuario = require('../models/Usuario');
const { JWT_SECRET } = require('../config');

exports.registro = async (req, res) => {
  try {
    const { nombre, email, password } = req.body;
    const existe = await Usuario.findOne({ email });
    if (existe) return res.status(400).json({ mensaje: 'El email ya está registrado' });
    const user = await Usuario.create({ nombre, email, password });
    res.status(201).json({ _id: user._id, nombre: user.nombre, email: user.email });
  } catch (err) {
    res.status(500).json({ mensaje: 'Error registrando usuario', error: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await Usuario.findOne({ email });
    if (!user) return res.status(400).json({ mensaje: 'Credenciales inválidas' });
    const ok = await user.compararPassword(password);
    if (!ok) return res.status(400).json({ mensaje: 'Credenciales inválidas' });
    const token = jwt.sign({ id: user._id, email: user.email }, JWT_SECRET, { expiresIn: '8h' });
    res.json({ token, usuario: { _id: user._id, nombre: user.nombre, email: user.email } });
  } catch (err) {
    res.status(500).json({ mensaje: 'Error en login', error: err.message });
  }
};

exports.perfil = async (req, res) => {
  try {
    const user = await Usuario.findById(req.user.id).select('-password');
    res.json(user);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error obteniendo perfil', error: err.message });
  }
};