const Votacion = require('../models/Votacion');
const Camiseta = require('../models/Camiseta');

exports.votar = async (req, res) => {
  try {
    const { camisetaId, voto } = req.body;
    if (!['positivo', 'negativo'].includes(voto)) {
      return res.status(400).json({ mensaje: 'Voto inválido' });
    }
    const existeCamiseta = await Camiseta.findById(camisetaId);
    if (!existeCamiseta) return res.status(404).json({ mensaje: 'Camiseta no existe' });

    const registro = await Votacion.findOneAndUpdate(
      { usuario: req.user.id, camiseta: camisetaId },
      { $set: { voto } },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    res.status(201).json(registro);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error al votar', error: err.message });
  }
};

exports.resumenPorCamiseta = async (req, res) => {
  try {
    const { id } = req.params;
    const agg = await Votacion.aggregate([
      { $match: { camiseta: require('mongoose').Types.ObjectId.createFromHexString(id) } },
      { $group: { _id: '$voto', total: { $sum: 1 } } }
    ]);
    const result = { positivo: 0, negativo: 0 };
    agg.forEach(a => result[a._id] = a.total);
    res.json(result);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error en resumen de votos', error: err.message });
  }
};

exports.listaConVotos = async (_req, res) => {
  try {
    const camisetas = await Camiseta.find().lean();
    const votos = await Votacion.aggregate([
      { $group: { _id: '$camiseta', positivos: { $sum: { $cond: [{ $eq: ['$voto', 'positivo'] }, 1, 0] } }, negativos: { $sum: { $cond: [{ $eq: ['$voto', 'negativo'] }, 1, 0] } } } }
    ]);
    const mapa = new Map(votos.map(v => [String(v._id), v]));
    const resp = camisetas.map(c => {
      const v = mapa.get(String(c._id)) || { positivos: 0, negativos: 0 };
      return { ...c, votos: v };
    });
    res.json(resp);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error listando camisetas con votos', error: err.message });
  }
};