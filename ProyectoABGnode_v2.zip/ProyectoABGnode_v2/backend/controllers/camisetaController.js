const Camiseta = require('../models/Camiseta');
const path = require('path');
const fs = require('fs');
const { UPLOADS_DIR } = require('../config');

exports.listar = async (req, res) => {
  try {
    const camisetas = await Camiseta.find().sort({ createdAt: -1 });
    res.json(camisetas);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error listando camisetas', error: err.message });
  }
};

exports.obtener = async (req, res) => {
  try {
    const c = await Camiseta.findById(req.params.id);
    if (!c) return res.status(404).json({ mensaje: 'No encontrada' });
    res.json(c);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error obteniendo camiseta', error: err.message });
  }
};

exports.crear = async (req, res) => {
  try {
    const { color, talla, descripcion } = req.body;
    const imagen = req.file ? req.file.filename : undefined;
    const nueva = await Camiseta.create({ color, talla, descripcion, imagen });
    res.status(201).json(nueva);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error creando camiseta', error: err.message });
  }
};

exports.actualizar = async (req, res) => {
  try {
    const { color, talla, descripcion } = req.body;
    const c = await Camiseta.findById(req.params.id);
    if (!c) return res.status(404).json({ mensaje: 'No encontrada' });

    if (req.file) {
      // eliminar imagen anterior si existe
      if (c.imagen) {
        const prev = path.join(__dirname, '..', UPLOADS_DIR, c.imagen);
        if (fs.existsSync(prev)) fs.unlinkSync(prev);
      }
      c.imagen = req.file.filename;
    }
    if (color) c.color = color;
    if (talla) c.talla = talla;
    if (descripcion !== undefined) c.descripcion = descripcion;

    await c.save();
    res.json(c);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error actualizando camiseta', error: err.message });
  }
};

exports.eliminar = async (req, res) => {
  try {
    const c = await Camiseta.findById(req.params.id);
    if (!c) return res.status(404).json({ mensaje: 'No encontrada' });
    if (c.imagen) {
      const prev = path.join(__dirname, '..', UPLOADS_DIR, c.imagen);
      if (fs.existsSync(prev)) fs.unlinkSync(prev);
    }
    await c.deleteOne();
    res.json({ mensaje: 'Eliminada' });
  } catch (err) {
    res.status(500).json({ mensaje: 'Error eliminando camiseta', error: err.message });
  }
};