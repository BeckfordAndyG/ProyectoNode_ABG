require('dotenv').config();

module.exports = {
  PORT: process.env.PORT || 3000,
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/proyectoabg',
  JWT_SECRET: process.env.JWT_SECRET || 'super_secreto_de_andy_beckford',
  FRONTEND_DIR: process.env.FRONTEND_DIR || '../frontend',
  UPLOADS_DIR: process.env.UPLOADS_DIR || 'uploads'
};